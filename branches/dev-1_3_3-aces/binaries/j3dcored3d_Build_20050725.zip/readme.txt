
======================================================
Java3D 1.3.2 D3D - binary library for D3D DirectX 9.0c
===================================================vvvv

Overview
========

This is the porting of Java3D native API D3D DirectX from 
8.1 to 9.0c. 
As it is highly based upon previous D3D 8.1, still there
some old limitations, as no line pattern or width. 
Most of those fixes are planned to be solved in the version 
for Java3D 1.4.0.


Installation
============

Just unzip the file j3dcore-d3d.dll in your JRE/bin folder.


Usage
======
To enable rendering using D3D, use the option j3d.rend=d3d.
Ex.:

java -Dj3d.rend=d3d HelloUniverse


Requeriments
=============
Java JRE 1.4.1 or higher;
Java3D 1.3.2 (Win32);
O.S: Windows 98SE, Windows 2000, Windows XP, Windows2003
DirectX: DirectX 9.0c runtime.
DirectX is available for download in the following link:

www.microsoft.com/windows/directx/downloads

========
Hystory
========
Build 2005.07.17

 Project and source code upgraded from VS 6.0 to 
 VS 2003.NET. Several fixes where made to match 
 new IDE.
 
 Several small fixes were applied to improve stability 
 and performance on TnL and non-TnL video cards, 
 specialy those made by Intel. 

 Added 2 new command line options:
  * j3d.d3dVertexProcess
  * j3d.useNvPerfHUD
  
  Option j3d.d3dVertexProcess allows user to choose the 
  Vertex Processing strategy : at GPU, at CPU or mixed.
  This option can have one of the following values:
      hardware - force Vertex Processing be done by GPU;
      software - force Vertex Processing be done by CPU;
      mixed - force Vertex Processing be done by GPU 
              where it is possible, and by CPU in 
              the other cases.
              
  The default option is automatic, Java3D choosing the best 
  based in DirectX caps, i.e hardware vertex processing 
  wherever it is possible.
           
  Option  j3d.useNvPerfHUD is used to enable Java3D applications be
  performance profilled with NVidia NvPerfHUD. 
  It also forces rendered to use hardware vertex processing.
  Detailed info and free download of NvPerfHUD in the link below:
  http://developer.nvidia.com/object/nvperfhud_home.html
  
  
  Build 2005.05.21
  
   Stable after fixing several small bugs. First build available for
   betatesting.
   
   
