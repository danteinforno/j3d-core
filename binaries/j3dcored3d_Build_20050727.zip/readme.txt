
======================================================
Java3D 1.3.2 D3D - binary library for D3D DirectX 9.0c
===================================================vvvv

Overview
========

This is the porting of Java3D native API D3D from DirectX 
8.1 to DirectX 9.0c. 
As it is highly based upon previous D3D 8.1, still there
some limitations, as no line pattern or line width. 
Some of those fixes are planned to be solved in the next 
version, for Java3D 1.4.0.


Installation
============
Just unzip the file j3dcore-d3d.dll in your JRE/bin folder.


Usage
======
To enable rendering using D3D, use the option j3d.rend=d3d
Ex.:

java -Dj3d.rend=d3d HelloUniverse


Requirements
=============
Java JRE 1.4.1 or higher;
Java3D 1.3.2 (Win32);
O.S: Windows 98SE, Windows 2000, Windows XP, Windows2003
Processor : Intel X86 Pentium compatible.
DirectX: DirectX 9.0c (or higher)  runtime.
DirectX is available for download in the following link:
http://www.microsoft.com/windows/directx/downloads


Bugs & Suggestions
==================
If you found a bug or have sugestions, please post it at 
Java3D forum: 
http://www.javadesktop.org/forums/forum.jspa?forumID=55

When you found a bug, do not forget to describe your system, 
like the following example:

OS: Windows 2000 professional Service Pack 4
Video card model: NVidia GeForce FX5700LE
Video Driver: ForceWare 77.72
Video Mode: 1152x864-32ColorBits @75Hz
CPU : AMD Athlon XP 2000


==========
 Hystory
==========

## Build 2005.07.27

 Vertex processing now chooses MIXED mode for video cards
 with TnL capability but without Shader support. This will
 improve performance of video cards like NVidia GeForce2 and
 GeForce4 MX. TnL card with Shader support will use
 hardware processed.



## Build 2005.07.17

 Project and source code upgraded from VSC 6.0 to 
 VSC 2003.NET. Several fixes where made to match 
 new C++ convection in this new IDE.
 
 Several small fixes were applied to improve stability 
 and performance on both TnL and non-TnL video cards, 
 specially Intel video cards. 

 Added 2 new command line options:
  * j3d.d3dVertexProcess
  * j3d.useNvPerfHUD
  
 #Option j3d.d3dVertexProcess allows user to choose the 
  Vertex Processing strategy : hardware accelerated by GPU, 
  software by CPU or mixed.
  This option can have one of the following values:
      hardware - force Vertex Processing be done by GPU;
      software - force Vertex Processing be done by CPU;
      mixed - force Vertex Processing be done by GPU 
              where it is possible, and by CPU in 
              the other cases.
              
  The default option is automatic, Java3D choosing the best 
  based in DirectX Caps.
  Usage examples:
  java -Dj3d.rend=d3d -Dj3d.d3dVertexProcess=software  My3DApp
  java -Dj3d.rend=d3d -Dj3d.d3dVertexProcess=mixed   My3DApp
  java -Dj3d.rend=d3d -Dj3d.d3dVertexProcess=hardware My3DApp
  
  Tip: you can also include -Dj3d.debug=true for extra info

         
 #Option  j3d.useNvPerfHUD is used to enable Java3D applications 
  be performance profilled with NVidia NvPerfHUD tool. 
  It also forces rendered to use hardware vertex processing.
  Detailed info and free download of NvPerfHUD in the link below:
  http://developer.nvidia.com/object/nvperfhud_home.html
  Usage :
  After correct install of NvPerfHud, create a bat file 
  to start your application, with statement like this:
  java -Dj3d.rend=d3d -Dj3d.useNvPerfHUD=true  My3DApp

  At command line, type :
  NvPerfHud <path_to_my_app_startUp_bat_file> 
  Or drag and drop your bat file over NvPerfHUD icone at desktop.
  Read NvPerfHUD doc.    
    
  
###  Build 2005.05.21
  
   Stable after fixing several small bugs. First build available for
   beta-testing.

======================================================   

Alessandro Borges (aces)
alessandroborges@yahoo.com.br
Brasilia-Brazil

   